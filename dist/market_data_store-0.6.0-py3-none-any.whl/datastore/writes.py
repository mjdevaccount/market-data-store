# Intentionally minimal; orchestrator will import this package to write data.
# Add upserts/batch writers after schema decisions.
