"""Market Data Store - Persistence and CQRS-lite store for market data."""

__version__ = "0.2.0"
