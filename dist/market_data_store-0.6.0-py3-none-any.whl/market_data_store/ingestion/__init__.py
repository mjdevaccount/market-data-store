"""Data ingestion module for market data store."""
