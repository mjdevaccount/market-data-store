"""Query module for market data store."""
